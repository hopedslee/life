<HTML>
<HEAD>
<meta charset="utf-8">
<style>  
table, th, td {
  border: 1px dotted black;
}
</style>

<script type="text/javascript" language="javascript">
function open_account_iframe(){
	alert("AAAAA");
	var pop_title = "popupOpener" ;
	window.open("", pop_title) ;
	var frmData = document.frmData ;
	frmData.target = pop_title ;
	frmData.action = "account_iframe.php" ;
	frmData.submit() ;
}

function displayDw() {
	document.getElementById("depwit").textContent = "hello";	
}


</script>

</HEAD>
<body>
<font color=black size=3>
<img src="dsr_logo.jpg" "width=500" alt="logo" />
<?php echo "<br />"; ?>
&copy; DSRobotec Trade Monitoring v.2021-04-25
<?php
date_default_timezone_set('Asia/Seoul');
$thistime=date("Y-m-d H:i:s");
$systemtime=strtotime("-7 hours");
$londontime=strtotime("-9 hours");
$newyorktime=strtotime("-13 hours");
//-------------------------------------------------
echo "/ (SYS): ".date("Y-m-d H:i:s",$systemtime)."<BR>";
echo "(LOC): ".$thistime." / ";
echo "(LON): ".date("Y-m-d H:i:s",$londontime)." / ";
echo "(N Y): ".date("Y-m-d H:i:s",$newyorktime)."<BR>";


function getHeartbeat()
{
$thistime=date("Y-m-d H:i:s");	
$mysqli_charset = 'utf8';
$masteraccount = 633124;
require('../dbconn.php');

$conn=mysqli_connect($host,$user,$passwd,$dbname);
$tbl="ea_heartbeat";

echo "<table class='mytable' border='1'>";
echo "<tr style='background-color:yellow'>";
echo "<th>no</th><th>broker</th><th align=center>acno</th><th>Tr</th><th>acname</th><th>IB</th><th>CY</th>";
echo "<th>deposit</th><th>wdraw</th><th>balance</th><th>gap</th><th>equity</th><th>gain</th><th>MLEV</th>";
echo "<th align=center>MT4</th><th>orders(CPs)</th><th>swap</th>";
//echo "<th>touch_time</th><th>elapsed</th><th align=center>server</th><th>mfb</th><th>pub</th></tr>";
echo "<th>touch_time</th><th>elapsed</th><th align=center>server</th>";
echo "<th align=center>flagprice</th>";
echo "<th align=center>D/W</th></tr>";

$query="SELECT orders, CPs, flagprice FROM $tbl where acno='$masteraccount' ";
$result=mysqli_query($conn,$query) or die(mysqli_error());
$array = mysqli_fetch_array($result);
$morders=$array['orders'];
$mCPs=$array['CPs'];
$flagprice=$array['flagprice'];


$query="SELECT * FROM $tbl where visible=1 ORDER BY remark ASC";
$result=mysqli_query($conn,$query) or die(mysqli_error());

$i=0;
$rowbgcolor="<tr>";

while( $array = mysqli_fetch_array($result) )
{
	$i++;  
	if($i % 2 == 1)
	{
	  $rowbgcolor="<tr style='background-color:#D6D5D5'>";
	}
	elseif($i % 2 == 0)
	{
	  $rowbgcolor="<tr style='background-color:#ffffff'>";
	}

	echo $rowbgcolor;
	
	$elapsed=strtotime($thistime)-strtotime($array['touch_time']);
	if($elapsed > 900) //1500) 
	{
		$timebgcolor="<th align=center bgcolor=#F5FB6E><i>"; //#CCCC00>"; // #FFFF33>"; //#FF0000>";
	}
	else 
	{
		$timebgcolor="<td align=center>";
	}

	if($array['ml']>0 && $array['ml']<800)
	{
		$mlbgcolor="<td align=right bgcolor=#FF0000>";
	}
	else                
		$mlbgcolor="<td align=right>";
	
	echo "<td align=center>".$i."</td>";
	if($array['broker'] != 'ICM')
		echo "<th align=center>".$array['broker']."</th>";
	else
		echo "<td align=center>".$array['broker']."</td>";
	//echo "<td align=center>".$array['remark']."</td>";
	if($array['acno']=="633124") echo "<td align=center><b>".$array['acno']."</b></td>";
	else echo "<td align=center>".$array['acno']."</td>"; 
	echo "<td><input type=button onClick=window.open('transaction.php?acno=".trim($array['acno'])."','aaa','width=1500,height=1000,left=150,top=200,toolbar=yes,status=yes,'); value='Tr'></td>";
	echo "<td>".ucwords(strtolower($array['acname']))."</td>";

	echo "<td align=center>".$array['IB']."</td>";
	if($array['currency'] != "USD") echo "<td align=center><b><font color='#e7503c'><SPAN style='font-size:4pt'>".$array['currency']."</b></td>";
	else echo "<td align=center><SPAN style='font-size:4pt'>".$array['currency']."</td>";	
	
	if($array['currency'] == "HKD")
	{
		$array['deposit'] = $array['deposit']*0.13;
		$array['withdrawal'] = $array['withdrawal']*0.13;
		$array['balance'] = $array['balance']*0.13;	
		$array['equity'] = $array['equity']*0.13;	
	}
	echo "<td align=right>".number_format($array['deposit'])."</td>";
	echo "<td align=right>".number_format($array['withdrawal'])."</font></td>";
	echo "<td align=right>".number_format($array['balance'])."b</td>";
	echo "<td align=right>".number_format($array['equity']-$array['balance'])."</td>";
	echo "<td align=right><font color='#3c61e7'><b>".number_format($array['equity'])."</b>e</td>";
	$gain=$array['equity']-$array['deposit']+$array['withdrawal'];	// gain 실손익

	if($gain>0)
		echo "<th align=right>".number_format($gain)."<font>g</th>";
	else
		echo "<th align=right><font color='#e7503c'>".number_format($gain)."<font>g</th>";

	echo $mlbgcolor.number_format($array['ml'])."%</th>";
	echo "<th align=center>".$array['remark']."</th>";

	if($morders != $array['orders'] or $mCPs != $array['CPs']) 
		echo "<th><i>".number_format($array['orders'],0)."(".$array['CPs'].")</i></th>";
	else 
		echo "<td align=center>".number_format($array['orders'],0)."(".$array['CPs'].")</td>";
	echo "<td align=right>".number_format($array['swap'],2)."</td>";
	echo $timebgcolor.date('d H:i:s',strtotime($array['touch_time']))."</td>";
	echo $timebgcolor.$elapsed."</i></td>";
	echo "<td align=center>".$array['server']."</td>";
	if($flagprice == $array['flagprice']) echo "<td align=center>".$array['flagprice']."</td>";
	else echo "<td align=center style='background-color:#FFFF00'f><b>".$array['flagprice']."</b></td>";
	$dw = $array['depwit'];
	if($dw==NULL)
		echo "<td align=center>-</td>";
	else
	{
		echo "<td><input style='background-color:yellow' type=button onClick=window.open('depwit.php?acno=".trim($array['acno'])."','aaa','width=1500,height=1000,left=150,top=200,toolbar=yes,status=yes,'); value='dw'></td>";
	}
	echo "<tr>";
}
//                   0           1            2           3           4
$query="SELECT sum(deposit), sum(balance), sum(equity), sum(swap), sum(withdrawal) FROM $tbl WHERE type='real' and visible=1";
$result=mysqli_query($conn,$query) or die(mysqli_error());
if($result==FALSE) die("Select sum failed: ".mysqli_error);
$row=mysqli_fetch_row($result);
  echo "<td></td><td></td><td></td><td></td><td></td><td></td><td>sum</td><td></td><td>".number_format($row[0])."</td>";
  echo "<td>".number_format($row[4])."</td>";
  echo "<td align=right>".number_format($row[1])."</td>";
  echo "<td align=right>".number_format($row[2]-$row[1])."</td>";
  echo "<td align=right><font color='#3c61e7'><b>".number_format($row[2])."</b></td>";
  echo "<td align=right>".number_format($row[2]-$row[0]+$row[4])."</td>";
  echo "<td></td>";
  echo "<td></td><td align=right>".number_format($row[3])."</td>";
  echo "<td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";
echo "</table>";
}// function getHeartbeat()

Getheartbeat();

//mysqli_close($conn);

?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<script>
function clear_sms(id){
	//alert("id=",id);
    trid=id.split('-')[2];
	alert("acno="+trid);
    $.ajax(
		{
			url:  "update.php",
			type: "POST",
			data:{ acno : id },
			success: function(result){
				//alert(result);
				//$('table#sTbl tr#'+trid).remove();
				window.location.reload(); 
			}
		}
	);
}

function link_mfb(id){
    trid=id.split('-')[1];
	alert(id);
	//alert("link="+trid);

    $.ajax(
		{
			url:  "link.php",
			type: "POST",
			data:{ acno : id },
			success: function(result){
				//alert(result);
				//$('table#sTbl tr#'+trid).remove();
				window.location.reload(); 
			}
		}
	);
}
</script>

</font>
</body>
</HTML>
