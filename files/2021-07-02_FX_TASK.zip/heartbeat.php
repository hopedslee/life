<?php
$acno=$_GET["acno"];
$server=$_GET["server"];
$acname=$_GET["acname"];
$balance=$_GET["balance"];
$equity=$_GET["equity"];
$ml=$_GET["ml"];
$orders=$_GET["orders"];
$CPs=$_GET["CPs"];
//$bl=$_GET["bl"];
//$sl=$_GET["sl"];
//$nl=$_GET["nl"];
$swap=$_GET["swap"];
$remark=$_GET["remark"];
$flagprice=$_GET["flagprice"];
$depwit=$_GET["depwit"];

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$ipaddress=get_client_ip();

require('../dbconn.php');

//$conn=mysqli_connect("localhost:3306","dslee","A2lds7707!","dslee_db");
//if (mysqli_connect_errno($conn)) exit ("DB connect fail : " . (mysqli_connect_error()) ); 		

$tbl1="ea_heartbeat";
$tbl2="OrdersHistory";

$sql = "SELECT * from $tbl1 WHERE acno = '$acno' ";
$result=mysqli_query($conn,$sql) or die( mysqli_error($conn) );

if(mysqli_num_rows($result)>0)	// record is already exists
{
	$sql = "SELECT sum(Deposit), sum(Withdrawal) FROM $tbl2 where Account=$acno";
		
	$query = mysqli_query($conn,$sql) or die(mysqli_error($conn));

	//echo "$query=".$query;
	$fund = mysqli_fetch_array($query);
	if($fund[0]==NULL) $fund[0]=0;
	if($fund[1]==NULL) $fund[1]=0;

	/*
	if($fund <= 0)
	{
		echo $fund[0]." ".fund[1]."<br />";
		$fund[0]=0;
		$fund[1]=0;
	}
	*/
	$sql="UPDATE $tbl1 SET touch_time=CURRENT_TIMESTAMP, server=$server, acname=$acname, equity=$equity, balance=$balance, ";
	$sql=$sql."ml=$ml, orders=$orders, CPs=$CPs, swap=$swap, vps_ip='$ipaddress', ";
	$sql=$sql."remark=$remark, deposit=$fund[0], withdrawal=$fund[1], flagprice=$flagprice, depwit=$depwit WHERE acno=$acno";

	//echo $sql.'<br />';
	$result=mysqli_query($conn, $sql) or die(mysqli_error());
	if($result) echo "UPDATE OK";
}
else
{
	$sql="INSERT INTO $tbl1 (touch_time, acno, type, visible) VALUES (CURRENT_TIMESTAMP, '$acno', 'real', '1')";	
	$result=mysqli_query($conn,$sql) or die(mysqli_error($conn));
	if($result) echo "INSERT OK";
}	
?>
