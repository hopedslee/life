<html>

<?php
$acno=$_GET['acno'];

require('../dbconn.php');

$query="SELECT acname,depwit FROM ea_heartbeat WHERE acno=$acno";
$result=mysqli_query($conn,$query) or die(mysqli_error());
$row = mysqli_fetch_row($result);
$acname=$row[0];
$depwit=$row[1];

$dw = explode( "/", $depwit);
$c = count($dw);

//echo $today;
echo "<table border='1'>";
echo "<tr><th>$acno</th><th>$acname</th></tr>";
for ($i=0; $i<$c; $i++)
{
	echo "<tr><td colspan='2'>".$dw[$i]."</td></tr>";
}
echo "</table>";

?>
<br />
<left><input type=button onClick="self.close();" value="Close this window"></center>
</html>